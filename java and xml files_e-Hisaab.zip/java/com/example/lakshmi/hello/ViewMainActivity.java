package com.example.lakshmi.hello;

/**
 * Created by lakshmi on 15/4/18.
 */

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.RequiresApi;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.androidbegin.buttonclicktutorial.R;


public class ViewMainActivity extends AppCompatActivity {
    //TextView textview=(TextView) findViewById(R.id.textView1);
    myDbAdapter helper= new myDbAdapter(this);
    Button enableButton;
    EditText Month;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view);
        final TextView textView1=(TextView)findViewById(R.id.textView1);
        Month= (EditText) findViewById(R.id.editText1);

        enableButton=(Button)findViewById(R.id.button1);
        enableButton.setOnClickListener(new OnClickListener(){

            public void onClick(View view){

                try{
                    //Log.d("check","I am called");

                    /*int t=0;
                    t=helper.getData();
                    Log.d("check",String.valueOf(t));
                    System.out.println(t);*/

                    String data="           Month"+"            Date            "+"Expense\n";
                    //String m1="jan";
                    String t1 = Month.getText().toString();
                    data = data + helper.getData(t1);
                    String data1 = helper.getSum(t1);
                    //Message.message(this,data);

                    textView1.setText(data+"\n"+data1);
                }
                    catch(Exception e)
                    {
                       e.printStackTrace();
                    }

            }
        });

    }





    // Message.message(this,data);


}
