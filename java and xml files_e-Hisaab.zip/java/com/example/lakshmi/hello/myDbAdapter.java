package com.example.lakshmi.hello;

/**
 * Created by lakshmi on 15/4/18.
 */

import android.content.ContentValues;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;


/**
 * Created by lakshmi on 14/4/18.
 */

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import static android.app.PendingIntent.getActivity;
import static android.content.Context.*;


public class myDbAdapter {
    myDbHelper myhelper;
    public myDbAdapter(Context context)
    {
        myhelper = new myDbHelper(context);
    }
    public long insertData(String month, String date,String expense)
    {
        SQLiteDatabase dbb = myhelper.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(myDbHelper.MONTH, month);
        contentValues.put(myDbHelper.DATE, date);
        contentValues.put(myDbHelper.EXPENSE, expense);
        //System.out.println("month"+month+date+expense);
        long id = dbb.insert(myDbHelper.TABLE_NAME, null , contentValues);
        System.out.println("id hello"+id);
        return id;
    }


    public String getData(String mon) {
        // List students = new ArrayList();
        SQLiteDatabase db = myhelper.getWritableDatabase();
        String query = "SELECT * from myTable where Month like '"+mon+"'";
        Cursor cursor = db.rawQuery(query, null);
        //Log.d("check", "get data called");
        StringBuffer buffer= new StringBuffer();
        while (cursor.moveToNext()) {

            int id = cursor.getInt(0);
            String month = cursor.getString(1);
            String date = cursor.getString(2);
            String expense = cursor.getString(3);
            System.out.println(id + "          " + month);
            buffer.append("      " + month + "              " + date +"                "+expense +" \n");
        }
        return buffer.toString();

        //  db.close();
    }
    public String getSum(String mon) {
        // List students = new ArrayList();
        SQLiteDatabase db = myhelper.getWritableDatabase();
        String query = "SELECT * from myTable where Month like '"+mon+"'";
        Cursor cursor = db.rawQuery(query, null);
        //Log.d("check", "get data called");
        StringBuffer buffer= new StringBuffer();
        int sum=0;
        while (cursor.moveToNext()) {

            int id = cursor.getInt(0);
            String month = cursor.getString(1);
            String date = cursor.getString(2);
            String expense = cursor.getString(3);
            sum= sum+Integer.parseInt(expense);
            System.out.println(id + "          " + month);

        }
        buffer.append("Total expense of " +mon+" is "+sum);
        return buffer.toString();

        //  db.close();
    }
        /*SQLiteDatabase db = SQLiteDatabase.openOrCreateDatabase(myDbHelper.DATABASE_NAME, null);
        String[] columns = {myDbHelper.UID,myDbHelper.MONTH,myDbHelper.DATE,myDbHelper.EXPENSE};
        Cursor cursor = db.query(myDbHelper.TABLE_NAME,columns,null,null,null,null,null);
        cursor.moveToFirst();
        String month=cursor.getString(1);
        System.out.println(month);
        return 1;*/

    /*public String getData()
    {
        System.out.println("hi");
        SQLiteDatabase db = myhelper.getWritableDatabase();
        String[] columns = {myDbHelper.UID,myDbHelper.MONTH,myDbHelper.DATE,myDbHelper.EXPENSE};
        Cursor cursor =db.query(myDbHelper.TABLE_NAME,columns,null,null,null,null,null);
        StringBuffer buffer= new StringBuffer();
        while (cursor.moveToNext())
        {
            int cid =cursor.getInt(cursor.getColumnIndex(myDbHelper.UID));
            String month =cursor.getString(cursor.getColumnIndex(myDbHelper.MONTH));
            System.out.println(month);
            String  date =cursor.getString(cursor.getColumnIndex(myDbHelper.DATE));
            String  expense =cursor.getString(cursor.getColumnIndex(myDbHelper.EXPENSE));
            buffer.append( month + "   " + date +"    "+expense+" \n");
        }
        return buffer.toString();
    }
*/
    static class myDbHelper extends SQLiteOpenHelper
    {
        private static final String DATABASE_NAME = "myDatabase";    // Database Name
        private static final String TABLE_NAME = "myTable";   // Table Name
        private static final int DATABASE_Version = 1;    // Database Version
        private static final String UID="_id";     // Column I (Primary Key)
        private static final String MONTH = "Month";    //Column II
        private static final String DATE="Date";  // Column III
        private static final String EXPENSE="Expense"; //Column IV
        private static final String CREATE_TABLE = "CREATE TABLE "+TABLE_NAME+
                " ("+UID+" INTEGER PRIMARY KEY AUTOINCREMENT, "+MONTH+" VARCHAR(255) ,"+DATE+" VARCHAR(255) ,"+ EXPENSE+" VARCHAR(225));";
        private static final String DROP_TABLE ="DROP TABLE IF EXISTS "+TABLE_NAME;
        private Context context;

        public myDbHelper(Context context) {
            super(context, DATABASE_NAME, null, DATABASE_Version);
            this.context=context;
        }

        public void onCreate(SQLiteDatabase db) {


            try {

                db.execSQL(CREATE_TABLE);

            } catch (Exception e) {

            }
        }

        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            try {

                db.execSQL(DROP_TABLE);
                onCreate(db);
            }catch (Exception e) {

            }
        }
    }
}
