package com.example.lakshmi.hello;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;

import com.androidbegin.buttonclicktutorial.R;


public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    }

    public void adddata(View view)
    {

        Intent intent = new Intent(MainActivity.this, AddMainActivity.class);
        startActivity(intent);
    }
    public void viewdata(View view)
    {


        Intent intent = new Intent(MainActivity.this, ViewMainActivity.class);
        startActivity(intent);
    }


}
