package com.example.lakshmi.hello;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;

import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

import com.androidbegin.buttonclicktutorial.R;

public class AddMainActivity extends Activity {
    //Button button;
    EditText Month, Date,Expense ;
    myDbAdapter helper;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Get the view from activity_main.xml
        setContentView(R.layout.activity_add);
        Month= (EditText) findViewById(R.id.editText1);
        Date= (EditText) findViewById(R.id.editText2);
        Expense= (EditText) findViewById(R.id.editText3);
        helper = new myDbAdapter(this);
        // Locate the button in activity_main.xml

    }
    public void adddata(View view)
    {
        String t1 = Month.getText().toString();
        String t2 = Date.getText().toString();
        String t3 = Expense.getText().toString();


        long id = helper.insertData(t1,t2,t3);
        System.out.println(id);
        if(id<=0)
        {
            Message.message(getApplicationContext(),"Insertion Unsuccessful");
            Month.setText("");
            Date.setText("");
            Expense.setText("");

        } else
        {
            Message.message(getApplicationContext(),"Insertion Successful");
            Month.setText("");
            Date.setText("");
            Expense.setText("");
        }
    }
    public void viewdata(View view)
    {


        Intent intent = new Intent(AddMainActivity.this, ViewMainActivity.class);
        startActivity(intent);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.activity_main, menu);
        return true;
    }
}
