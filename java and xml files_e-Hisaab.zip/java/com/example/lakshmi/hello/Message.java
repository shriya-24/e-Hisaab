package com.example.lakshmi.hello;

/**
 * Created by lakshmi on 15/4/18.
 */

import android.content.Context;
import android.widget.Toast;

public class Message {
    public static void message(Context context, String message) {
        Toast.makeText(context, message, Toast.LENGTH_LONG).show();
    }
}